# Packer Template for Ubuntu 18.04 LTS

To create the template execute **packer build -force -debug -on-error=ask -var-file variables.json ubuntu18-thick.json** 