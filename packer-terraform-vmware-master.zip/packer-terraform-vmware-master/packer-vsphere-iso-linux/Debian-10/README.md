# Packer Template for Debian 10 Linux

To create the template execute **packer build -var-file variables.json debian10.json** 

**Credentials:**

Username: kopicloud

Password: kopicloud
