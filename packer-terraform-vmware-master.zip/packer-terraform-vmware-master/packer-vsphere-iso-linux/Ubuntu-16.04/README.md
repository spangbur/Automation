# Packer Template for Ubuntu 16.04 LTS

To create the template execute **packer build -force -debug -on-error=ask -var-file variables.json ubuntu16-thick.json** for debugging.

Or execute **packer build -force -var-file variables.json ubuntu16-thick.json** for regular deployment.